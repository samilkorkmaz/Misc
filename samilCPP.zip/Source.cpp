#include <iostream>

int main() {
	std::cout << "Press enter..." << std::endl;
	std::cin.get();
}