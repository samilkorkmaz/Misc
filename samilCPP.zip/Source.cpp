//https://stackoverflow.com/a/612176/51358
#include <string>
#include <iostream>
#include <filesystem>
namespace fs = std::filesystem;

int main()
{
    std::string path = "C:/Users/sam/source/repos/Project5";
    for (const auto& entry : fs::directory_iterator(path))
        std::cout << entry.path() << std::endl;
	std::cout << "Press enter..." << std::endl;
	std::cin.get();
}